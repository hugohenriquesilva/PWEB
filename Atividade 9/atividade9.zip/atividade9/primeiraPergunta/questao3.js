function questao3 (){
   
    const palavra = prompt("Digite a palavra")
    
    const palavraInvertida = palavra.split('').reverse().join('')
    let resposta;
    if(palavra == palavraInvertida){
        resposta = ("É palíndromo")
    }
    else{
        resposta = ("Não é palíndromo")
    }


    
    alert (resposta)
}