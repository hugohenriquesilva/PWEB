function questao2 (){
   
    const numero1 = parseInt(prompt("Digito o 1° número"))
    const numero2 = parseInt(prompt("Digito o 2° número"))
    const numero3 = parseInt(prompt("Digito o 3° número"))

    let lista = [numero1, numero2, numero3]

    lista.sort((numero1, numero2) => numero1 - numero2)

    alert ("A lista ordenada fica dessa forma " + lista)
}
