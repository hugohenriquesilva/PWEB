
function questao1 (){
    const numero1 = parseInt(prompt("Digito o 1° número"))
    const numero2 = parseInt(prompt("Digito o 2° número"))
    const numero3 = parseInt(prompt("Digito o 3° número"))

    maiorNumero = Math.max(numero1, numero2, numero3)
    alert("O maior número é " + maiorNumero)
}
