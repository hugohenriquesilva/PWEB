function questao4 (){
    const numero1 = parseInt(prompt("Digito o 1° número"))
    const numero2 = parseInt(prompt("Digito o 2° número"))
    const numero3 = parseInt(prompt("Digito o 3° número"))

    let resposta;
    

   if (numero1 + numero2 > numero3 && numero3 + numero2 > numero1 && numero1 + numero3 > numero2){
        resposta = ("É triângulo")            
   }
   else{
        resposta = ("Não é triângulo")
   }

   alert(resposta)
}