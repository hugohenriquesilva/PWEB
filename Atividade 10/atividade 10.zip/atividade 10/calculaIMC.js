function calculaIMC(){
   
   const peso = parseFloat(document.getElementById('inpPeso').value)
   const altura = parseFloat(document.getElementById('inpAltura').value)

   const IMC = peso/ (altura*altura)
   let classificacao;

   if (IMC < 18.5){
    classificacao = "Magreza" 
   } else if (IMC >= 18.5 && IMC < 25){
    classificacao="Normal"
   }else if(IMC >=25 && IMC < 30){
    classificacao = "Sobrepeso"
   }else if (IMC >= 30 && IMC < 39.9){
    classificacao = "Obesidade"
   }else{
    classificacao = "Obesidade grave"
   }
   alert("Sua classificação é: " + classificacao);
}
