nome = prompt("Qual o nome do aluno?")
nota1 = parseFloat(prompt("Coloque a primeira nota"))
nota2 = parseFloat(prompt("Coloque a segunda nota"))
nota3 = parseFloat(prompt("Coloque a terceira nota"))
nota4 = parseFloat(prompt("Coloque a quarta nota"))

alert((nota1+nota2+nota3+nota4)/4)